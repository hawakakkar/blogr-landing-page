export default function App() {
  return (
    <div>
      <Navbar />
      <Product />
      <Company />
      <Content />
      <Footer />
    </div>
  );
}

function Navbar() {
  return (
    <div className="navbar">
      <div>
        <img
          className="image0"
          src="/images/bg-pattern-intro-desktop.svg"
          alt="Background"
        />

        <nav>
          <img className="image" src="/images/logo.svg" alt="Logo" />
          <ul>
            <li>
              Product <img src="/images/icon-arrow-light.svg" alt="arrow" />
            </li>

            <li>
              Company <img src="/images/icon-arrow-light.svg" alt="arrow" />
            </li>
            <li>
              Connect <img src="/images/icon-arrow-light.svg" alt="arrow" />
            </li>
          </ul>
          <button className="button0">Login</button>
          <button className="button1">Sign Up</button>
        </nav>
      </div>

      <h1>A modern Publishing platform</h1>
      <p>Grow your audience and build your online brand.</p>
      <button className="button2">Start For Free</button>
      <button className="button3">Learn More</button>
    </div>
  );
}

function Product() {
  return (
    <div className="Product">
      <img
        className="image4"
        src="/images/illustration-editor-desktop.svg"
        alt="Computer"
      />
      <h1>Designed for the future</h1>
      <h2>Introducing an extensuble editor </h2>
      <p>
        Blogr features an exceedingly intuitive interface which lets you focus
        on one thing: creating content. The editor supports management of
        multiple blogs and allows easy manipulation of embeds such as images,
        videos, and Markdown. Extensibility with plugins and themes provide easy
        ways to add functionality or change the looks of a blog.
      </p>
      <h2>Robust content management</h2>
      <p>
        Flexible content management enables users to easily move through posts.
        Increase the usability of your blog by adding customized categories,
        sections, format, or flow. With this functionality, you're in full
        control.
      </p>
    </div>
  );
}

function Company() {
  return (
    <section className="campany-section">
      <div className="container">
        <div className="images-wrapper">
          <img
            className="image6"
            src="/images/bg-pattern-circles.svg"
            alt="Logo"
          />
          <img
            className="image7"
            src="/images/illustration-phones.svg"
            alt="Logo"
          />
        </div>
        <div className="text-content">
          <h1>Stare of the Art interface</h1>
          <p>
            {/* Text content*/}
            With reliability and speed in mind, worldwide data centers provide
            the backbone for ultra-fast connectivity. This ensures your site
            will load instantly, no matter where your readers are, keeping your
            site competitive.
          </p>
        </div>
      </div>
    </section>
  );
}
function Content() {
  return (
    <div className="Content">
      <img
        className="image8"
        src="/images/illustration-laptop-desktop.svg"
        alt="Computer-picture-1"
      />
      <h2> Free, Open, Simple</h2>
      <p>
        Blogr is a free and open source application backed by a large community
        of helpful developers. It supports features such as code syntax
        highlighting. RSS feeds, social media integration, third-party
        commenting tools, and works seamlessly with Google Analytics. The
        architecture is clean and is relatively easy to learn.
      </p>
      <h2> Powerful tooling</h2>
      <p>
        Batteries included. We built a simple and straightforward CLI tool that
        makes customization and deployment a breeze, but capable of producing
        even the most complicated sites.
      </p>
    </div>
  );
}

function Footer() {
  return (
    <div className="footer">
      <section>
        <img className="image9" src="/images/logo.svg" alt="Logo" />
      </section>
      <section className="section5">
        <ul>
          <h2>Product</h2>
          <li>Overview</li>
          <li>Pricing</li>
          <li>Marketplace</li>
          <li>Features</li>
          <li>Integration</li>
        </ul>
      </section>
      <section>
        <ul>
          <h2>Company</h2>
          <li>About</li>
          <li>Team</li>
          <li>Blog</li>
          <li>careers</li>
        </ul>
      </section>

      <section>
        <ul>
          <h2>Connect</h2>
          <li>Contact</li>
          <li>Pricing</li>
          <li>LinkedIn </li>
        </ul>
      </section>
    </div>
  );
}
